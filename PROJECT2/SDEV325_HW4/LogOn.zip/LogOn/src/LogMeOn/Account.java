package LogMeOn;

public class Account {

    private String username = "sdev425admin";
    private String upass = "425!pass";

    public String getUsername() {
        return username;
    }

    public String getUpass() {
        return upass;
    }
}
